package com.taskpilot.controller;

import com.taskpilot.model.Task;
import com.taskpilot.repo.TaskRepository;
import com.taskpilot.service.NlpParser;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.time.LocalDate;
import java.util.*;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {
    private final TaskRepository repo;
    private final NlpParser parser;
    public TaskController(TaskRepository repo, NlpParser parser) { this.repo = repo; this.parser = parser; }

    public record CreateRequest(@NotBlank String title, LocalDate dueDate, String priority) {}
    public record QuickRequest(@NotBlank String text) {}
    public record StatusRequest(@NotBlank String status) {}

    @GetMapping
    public List<Task> all() { return repo.findAllByOrderByCreatedAtDesc(); }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Task create(@RequestBody CreateRequest req) {
        if (req.title() == null || req.title().isBlank()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Title is required");
        String p = normalizePriority(req.priority());
        return repo.save(new Task(req.title().trim(), req.dueDate(), p));
    }

    @PostMapping("/quick-add")
    @ResponseStatus(HttpStatus.CREATED)
    public List<Task> quickAdd(@RequestBody QuickRequest req) {
        try {
            List<Task> saved = new ArrayList<>();
            for (NlpParser.ParsedTask p : parser.parse(req.text())) {
                saved.add(repo.save(new Task(p.title(), p.dueDate(), p.priority())));
            }
            return saved;
        } catch (IllegalArgumentException ex) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, ex.getMessage());
        }
    }

    @PatchMapping("/{id}/status")
    public Task updateStatus(@PathVariable Long id, @RequestBody StatusRequest req) {
        Task task = repo.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Task not found"));
        String status = req.status().toUpperCase(Locale.ROOT);
        if (!Set.of("PENDING", "IN_PROGRESS", "COMPLETED").contains(status))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid status");
        task.setStatus(status);
        return repo.save(task);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        if (!repo.existsById(id)) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Task not found");
        repo.deleteById(id);
    }

    @GetMapping("/stats")
    public Map<String, Long> stats() {
        return Map.of("total", repo.count(), "pending", repo.countByStatus("PENDING"),
            "inProgress", repo.countByStatus("IN_PROGRESS"), "completed", repo.countByStatus("COMPLETED"),
            "overdue", repo.countOverdue());
    }

    private String normalizePriority(String p) {
        if (p == null) return "MEDIUM";
        String value = p.toUpperCase(Locale.ROOT);
        return Set.of("LOW", "MEDIUM", "HIGH").contains(value) ? value : "MEDIUM";
    }
}
