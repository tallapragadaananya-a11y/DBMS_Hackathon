package com.taskpilot.repo;

import com.taskpilot.model.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface TaskRepository extends JpaRepository<Task, Long> {
    List<Task> findAllByOrderByCreatedAtDesc();
    long countByStatus(String status);
    @Query("select count(t) from Task t where t.dueDate < current_date and t.status <> 'COMPLETED'")
    long countOverdue();
}
