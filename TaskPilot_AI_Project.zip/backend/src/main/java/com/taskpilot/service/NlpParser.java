package com.taskpilot.service;

import org.springframework.stereotype.Service;
import java.time.*;
import java.time.temporal.TemporalAdjusters;
import java.util.*;
import java.util.regex.*;

@Service
public class NlpParser {
    public record ParsedTask(String title, LocalDate dueDate, String priority) {}

    public List<ParsedTask> parse(String input) {
        if (input == null || input.isBlank()) throw new IllegalArgumentException("Please enter a task.");
        // Split common multi-task phrasing. Keep it intentionally simple and explainable for the MVP.
        String normalized = input.replaceAll("(?i)\\s+and\\s+(?=(?:finish|complete|submit|prepare|study|buy|call|email|attend|pay|review|create|do|work|read|practice|meet|send|make|build|write)\\b)", ";");
        String[] chunks = normalized.split("[;,\\n]+");
        List<ParsedTask> out = new ArrayList<>();
        for (String chunk : chunks) {
            String s = chunk.trim();
            if (s.isEmpty()) continue;
            String lower = s.toLowerCase(Locale.ROOT);
            String priority = "MEDIUM";
            if (lower.matches(".*\\b(urgent|critical|asap|high priority|important)\\b.*")) priority = "HIGH";
            else if (lower.matches(".*\\b(low priority|whenever|not urgent)\\b.*")) priority = "LOW";
            else if (lower.matches(".*\\b(medium priority|normal)\\b.*")) priority = "MEDIUM";

            LocalDate due = null;
            LocalDate today = LocalDate.now();
            if (lower.contains("day after tomorrow")) due = today.plusDays(2);
            else if (lower.matches(".*\\btomorrow\\b.*")) due = today.plusDays(1);
            else if (lower.matches(".*\\btoday\\b.*") || lower.matches(".*\\btonight\\b.*")) due = today;
            else if (lower.contains("next week")) due = today.with(TemporalAdjusters.next(DayOfWeek.MONDAY));
            else {
                for (DayOfWeek d : DayOfWeek.values()) {
                    String day = d.toString().toLowerCase(Locale.ROOT);
                    if (lower.contains("next " + day) || lower.matches(".*\\b" + day + "\\b.*")) {
                        due = today.with(TemporalAdjusters.next(d)); break;
                    }
                }
                Matcher m = Pattern.compile("\\b(in)\\s+(\\d{1,2})\\s+days?\\b").matcher(lower);
                if (due == null && m.find()) due = today.plusDays(Long.parseLong(m.group(2)));
            }
            String title = s.replaceAll("(?i)\\b(urgent|critical|asap|high priority|important|low priority|whenever|not urgent|medium priority|normal|today|tonight|tomorrow|day after tomorrow|next week|next monday|next tuesday|next wednesday|next thursday|next friday|next saturday|next sunday|monday|tuesday|wednesday|thursday|friday|saturday|sunday|in \\d{1,2} days?)\\b", "")
                    .replaceAll("\\s+", " ").replaceAll("^[,;:\\s]+|[,;:\\s]+$", "").trim();
            if (title.isBlank()) title = s;
            title = title.substring(0, Math.min(title.length(), 240));
            out.add(new ParsedTask(title, due, priority));
        }
        return out;
    }
}
