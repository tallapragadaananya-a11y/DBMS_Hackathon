package com.taskpilot.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "tasks")
public class Task {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 240)
    private String title;
    private LocalDate dueDate;
    @Column(nullable = false)
    private String priority = "MEDIUM";
    @Column(nullable = false)
    private String status = "PENDING";
    private LocalDateTime createdAt = LocalDateTime.now();

    public Task() {}
    public Task(String title, LocalDate dueDate, String priority) {
        this.title = title; this.dueDate = dueDate; this.priority = priority;
        this.status = "PENDING"; this.createdAt = LocalDateTime.now();
    }
    public Long getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String v) { title = v; }
    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate v) { dueDate = v; }
    public String getPriority() { return priority; }
    public void setPriority(String v) { priority = v; }
    public String getStatus() { return status; }
    public void setStatus(String v) { status = v; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
