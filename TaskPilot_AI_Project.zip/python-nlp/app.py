from datetime import date, timedelta
from fastapi import FastAPI
from pydantic import BaseModel
import re

app = FastAPI(title="TaskPilot NLP helper", version="1.0")

class Input(BaseModel):
    text: str

@app.post("/extract")
def extract(payload: Input):
    text = payload.text.strip()
    low = text.lower()
    due = None
    if "day after tomorrow" in low:
        due = date.today() + timedelta(days=2)
    elif "tomorrow" in low:
        due = date.today() + timedelta(days=1)
    elif "today" in low or "tonight" in low:
        due = date.today()
    elif m := re.search(r"in\s+(\d{1,2})\s+days?", low):
        due = date.today() + timedelta(days=int(m.group(1)))

    priority = "MEDIUM"
    if re.search(r"\b(urgent|critical|asap|high priority|important)\b", low):
        priority = "HIGH"
    elif re.search(r"\b(low priority|whenever|not urgent)\b", low):
        priority = "LOW"

    title = re.sub(r"\b(urgent|critical|asap|high priority|important|low priority|whenever|not urgent|today|tonight|tomorrow|day after tomorrow)\b", "", text, flags=re.I)
    title = re.sub(r"\s+", " ", title).strip(" ,;")
    return {"title": title or text, "dueDate": due.isoformat() if due else None, "priority": priority}
