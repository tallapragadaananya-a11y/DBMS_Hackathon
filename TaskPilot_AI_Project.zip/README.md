# TaskPilot AI — 2-hour MVP

A full-stack AI-style personal task assistant for Problem Statement 41.
- React + Vite frontend
- Java 21 + Spring Boot REST API
- MySQL persistence
- Rule-based NLP extraction in Java (keeps Java as the primary backend)
- Optional Python NLP microservice in `python-nlp/`

## 1. Requirements
Install:
- Java 21
- Maven 3.9+
- Node.js 20+
- MySQL 8+

## 2. Database
Create the database:
```sql
CREATE DATABASE taskpilot;
```
The backend uses:
- host: localhost
- port: 3306
- database: taskpilot
- username: root
- password: root

Change credentials in `backend/src/main/resources/application.properties` if needed.

## 3. Run backend
```bash
cd backend
mvn spring-boot:run
```
API runs at http://localhost:8080

## 4. Run frontend (new terminal)
```bash
cd frontend
npm install
npm run dev
```
Open the URL printed by Vite (normally http://localhost:5173).

## 5. Demo phrases
Paste these into the AI input:
- Finish Java assignment tomorrow urgent
- Prepare for DBMS exam next Monday medium priority
- Submit project report today high priority
- Buy notebook this weekend low priority

The parser supports multiple tasks separated by `and`, commas, or semicolons in simple sentences. It recognizes today, tomorrow, weekdays, next week, urgent/high/medium/low keywords.

## 6. API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/tasks` | List tasks |
| POST | `/api/tasks` | Create task manually |
| POST | `/api/tasks/quick-add` | Parse natural language and create task(s) |
| PATCH | `/api/tasks/{id}/status` | Update status |
| DELETE | `/api/tasks/{id}` | Delete task |
| GET | `/api/tasks/stats` | Dashboard counts |

Example quick-add:
```json
{ "text": "Finish Java assignment tomorrow urgent and prepare DBMS today" }
```

## 7. Optional Python NLP service
`python-nlp/` contains a tiny FastAPI extraction service. It is an optional enhancement; the main app works without it. Start it with:
```bash
cd python-nlp
pip install -r requirements.txt
uvicorn app:app --reload --port 8001
```
Endpoint: `POST http://localhost:8001/extract` with `{"text":"Finish assignment tomorrow urgent"}`.

## 8. What to explain to judges
1. User enters natural-language instructions.
2. NLP extracts task title, due date and priority.
3. React sends structured data to Spring Boot.
4. Spring Boot validates and stores it in MySQL.
5. Dashboard reads tasks and shows progress.
6. User can update status or delete tasks.

This is an MVP parser, not a general-purpose LLM. Be transparent: it uses keyword/date extraction and can be extended with an LLM or trained NLP model.
