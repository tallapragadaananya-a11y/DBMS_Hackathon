import { useEffect, useMemo, useState } from 'react'
import axios from 'axios'
import { Sparkles, Plus, Check, Trash2, CalendarDays, ListTodo, Clock3, CircleCheck, AlertTriangle, RefreshCw } from 'lucide-react'

const API = 'http://localhost:8080/api/tasks'
const examples = ['Finish Java assignment tomorrow urgent', 'Prepare DBMS exam next Monday medium priority', 'Submit project report today high priority']

function App() {
  const [tasks, setTasks] = useState([])
  const [stats, setStats] = useState({ total: 0, pending: 0, inProgress: 0, completed: 0, overdue: 0 })
  const [text, setText] = useState('')
  const [filter, setFilter] = useState('ALL')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  async function load() {
    try {
      const [t, s] = await Promise.all([axios.get(API), axios.get(`${API}/stats`)])
      setTasks(t.data); setStats(s.data); setError('')
    } catch { setError('Cannot reach backend. Start Spring Boot and make sure MySQL is running.') }
  }
  useEffect(() => { load() }, [])

  async function addTasks(e) {
    e.preventDefault()
    if (!text.trim()) return
    setLoading(true); setNotice(''); setError('')
    try {
      const res = await axios.post(`${API}/quick-add`, { text })
      setNotice(`${res.data.length} task${res.data.length === 1 ? '' : 's'} created from your instruction.`)
      setText(''); await load()
    } catch (e) { setError(e.response?.data?.message || 'Could not create tasks. Check the backend.') }
    finally { setLoading(false) }
  }
  async function updateStatus(task) {
    const next = task.status === 'PENDING' ? 'IN_PROGRESS' : task.status === 'IN_PROGRESS' ? 'COMPLETED' : 'PENDING'
    await axios.patch(`${API}/${task.id}/status`, { status: next }); await load()
  }
  async function removeTask(id) { await axios.delete(`${API}/${id}`); await load() }

  const visible = useMemo(() => tasks.filter(t => filter === 'ALL' || t.status === filter), [tasks, filter])
  const overdue = t => t.dueDate && new Date(`${t.dueDate}T00:00:00`) < new Date(new Date().toDateString()) && t.status !== 'COMPLETED'
  const dateLabel = d => d ? new Date(`${d}T00:00:00`).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : 'No deadline'

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-icon"><Sparkles size={20}/></div><span>TaskPilot<span className="brand-ai"> AI</span></span></div>
      <div className="side-label">WORKSPACE</div>
      <button className="nav active"><ListTodo size={18}/> My Tasks</button>
      <div className="side-note"><div className="side-note-icon"><Sparkles size={16}/></div><b>Work smarter</b><p>Turn your thoughts into an organized plan.</p></div>
      <div className="sidebar-bottom">AI-powered productivity<br/><span>TaskPilot v1.0</span></div>
    </aside>

    <main className="main">
      <header className="topbar"><div><div className="eyebrow">PERSONAL WORKSPACE</div><h1>Good morning <span>✦</span></h1><p className="subhead">Let's make today productive.</p></div><div className="avatar">TP</div></header>

      <section className="stats-grid">
        <Stat icon={<ListTodo/>} label="Total tasks" value={stats.total} tone="purple"/>
        <Stat icon={<Clock3/>} label="In progress" value={stats.inProgress} tone="blue"/>
        <Stat icon={<CircleCheck/>} label="Completed" value={stats.completed} tone="green"/>
        <Stat icon={<AlertTriangle/>} label="Overdue" value={stats.overdue} tone="orange"/>
      </section>

      <section className="ai-panel">
        <div className="ai-heading"><div className="ai-mark"><Sparkles size={20}/></div><div><h2>AI Task Creator</h2><p>Tell me what you need to get done. I'll organize it for you.</p></div><span className="ai-pill">SMART NLP</span></div>
        <form onSubmit={addTasks}>
          <textarea value={text} onChange={e => setText(e.target.value)} placeholder="e.g. Finish my Java assignment tomorrow and prepare for DBMS exam next Monday, urgent..." rows="3"/>
          <div className="composer-bottom"><span>✦ &nbsp;Dates and priorities are detected automatically</span><button className="primary" disabled={loading || !text.trim()}>{loading ? <RefreshCw className="spin" size={16}/> : <Sparkles size={16}/>} Create tasks</button></div>
        </form>
        <div className="examples"><span>TRY:</span>{examples.map(x => <button key={x} onClick={() => setText(x)}>{x}</button>)}</div>
      </section>

      {notice && <div className="notice"><Check size={16}/>{notice}</div>}
      {error && <div className="error">{error}</div>}

      <section className="tasks-section">
        <div className="section-head"><div><h2>Your tasks</h2><p>Stay focused on what matters.</p></div><button className="refresh" onClick={load}><RefreshCw size={16}/> Refresh</button></div>
        <div className="filters">{[['ALL','All tasks'],['PENDING','Pending'],['IN_PROGRESS','In progress'],['COMPLETED','Completed']].map(([v,l]) => <button key={v} className={filter===v?'selected':''} onClick={()=>setFilter(v)}>{l}</button>)}</div>
        <div className="task-list">
          {visible.length === 0 ? <div className="empty"><div>✦</div><b>No tasks here yet</b><p>Add a task above and let AI organize your day.</p></div> : visible.map(t => <article className={`task-card ${t.status==='COMPLETED'?'done':''}`} key={t.id}>
            <button className={`check-circle ${t.status==='COMPLETED'?'checked':''}`} onClick={()=>updateStatus(t)} title="Change status">{t.status==='COMPLETED'&&<Check size={14}/>}</button>
            <div className="task-info"><h3>{t.title}</h3><div className="task-meta"><span><CalendarDays size={13}/>{dateLabel(t.dueDate)}</span><span className={`priority ${t.priority.toLowerCase()}`}>{t.priority}</span><span className="status-label">{t.status.replace('_',' ')}</span>{overdue(t)&&<span className="overdue-label">OVERDUE</span>}</div></div>
            <button className="delete" onClick={()=>removeTask(t.id)} title="Delete task"><Trash2 size={17}/></button>
          </article>)}
        </div>
      </section>
      <footer>Built with <span>✦</span> AI · React · Spring Boot · MySQL</footer>
    </main>
  </div>
}
function Stat({icon,label,value,tone}) { return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div><div className="stat-value">{value}</div><div className="stat-label">{label}</div></div></div> }
export default App
