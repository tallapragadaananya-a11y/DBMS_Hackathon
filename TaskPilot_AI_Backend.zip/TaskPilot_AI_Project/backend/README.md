# TaskPilot AI - Backend (Spring Boot)

Converts natural-language sentences into structured tasks (title, due date, priority, status).

**Stack:** Java 21 · Spring Boot 3.3 · Spring Data JPA · MySQL (H2 fallback) · rule-based NLP engine

## Run

### Option A - MySQL (default)
1. Start MySQL. The app creates the `taskpilot` database automatically
   (or run `CREATE DATABASE taskpilot;` yourself).
2. Default login is `root` / `root`. To change it, either edit `application.properties`
   or set env vars `DB_USERNAME` and `DB_PASSWORD`.
3. ```
   cd backend
   mvn spring-boot:run
   ```
   API runs at http://localhost:8080

### Option B - no MySQL (in-memory H2, data resets on restart)
```
mvn spring-boot:run -Dspring-boot.run.profiles=h2
```

### Run the tests
```
mvn test
```

## API

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/tasks?status=&priority=` | List tasks (filters optional) |
| GET | `/api/tasks/{id}` | One task |
| POST | `/api/tasks` | Create task manually |
| POST | `/api/tasks/quick-add` | **AI**: sentence -> saved task(s) |
| POST | `/api/tasks/parse` | Dry run of the NLP, saves nothing |
| PUT | `/api/tasks/{id}` | Edit a task |
| PATCH | `/api/tasks/{id}/status` | Change status |
| DELETE | `/api/tasks/{id}` | Delete task |
| GET | `/api/tasks/stats` | Dashboard numbers |
| GET | `/api/tasks/suggestions` | Overdue + urgent tasks and messages |
| GET | `/api/tasks/history` | Full task history |
| GET | `/api/tasks/{id}/history` | History of one task |

### Try it
```bash
curl -X POST localhost:8080/api/tasks/quick-add -H "Content-Type: application/json" \
  -d '{"text":"I have to submit my Java assignment tomorrow, prepare for the DBMS exam next Monday, and finish my project presentation urgently."}'

curl -X PATCH localhost:8080/api/tasks/1/status -H "Content-Type: application/json" \
  -d '{"status":"COMPLETED"}'

curl localhost:8080/api/tasks/stats
```

Task JSON:
```json
{
  "id": 1, "title": "Submit Java assignment", "description": null,
  "dueDate": "2026-11-01", "priority": "HIGH", "status": "PENDING",
  "overdue": false, "sourceText": "...", "createdAt": "...", "updatedAt": "..."
}
```
Enums: priority `LOW|MEDIUM|HIGH`, status `PENDING|IN_PROGRESS|COMPLETED` (case-insensitive).
Errors return JSON `{status, error, message, details}` with 400 / 404.

## How the NLP works (for the judges)

`nlp/NlpTaskParser.java` is an explainable, rule-based pipeline:
1. **Split** the input into task clauses (punctuation, or "and/then" before an action verb).
2. **Priority**: keywords like *urgent, asap, high/medium/low priority, no rush, not urgent*.
3. **Deadline**: today, tomorrow, next Monday, this weekend, in 3 days, 5 Nov, 2026-11-05, 15/11/2026.
4. **Title**: strips filler ("I have to", "my") and the date/priority words.
5. **Inference** when no priority keyword: due <= 1 day -> HIGH, <= 7 days -> MEDIUM, later -> LOW.
   "Urgent" with no date means due today.

Date rules: "next Monday" = first Monday after today; "this Friday" = this week's Friday (today counts);
a bare weekday = next occurrence; day/month dates are day-first.

## Not implemented (don't claim these)
- Multi-user login/authentication (single shared dashboard)
- Time-of-day reminders, voice input, calendar sync

## Layout
```
src/main/java/com/taskpilot
  controller/  REST endpoints
  service/     business logic + history logging
  nlp/         NlpTaskParser (no Spring dependency, unit tested)
  model/       Task, TaskHistory, Priority, Status
  repository/  Spring Data JPA
  dto/         request/response records
  exception/   JSON error handling
  config/      CORS (React on :5173) + beans
```
