package com.taskpilot.nlp;

import static org.junit.jupiter.api.Assertions.*;

import com.taskpilot.model.Priority;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.Test;

class NlpTaskParserTest {

    // Saturday
    private static final LocalDate TODAY = LocalDate.of(2026, 10, 31);
    private final NlpTaskParser parser = new NlpTaskParser();

    @Test
    void urgentWithTomorrow() {
        List<ParsedTask> r = parser.parse("Finish my Java assignment tomorrow urgent", TODAY);
        assertEquals(1, r.size());
        assertEquals("Finish Java assignment", r.get(0).title());
        assertEquals(LocalDate.of(2026, 11, 1), r.get(0).dueDate());
        assertEquals(Priority.HIGH, r.get(0).priority());
    }

    @Test
    void explicitMediumPriorityNextMonday() {
        ParsedTask t = parser.parse("Prepare for DBMS exam next Monday medium priority", TODAY).get(0);
        assertEquals("Prepare for DBMS exam", t.title());
        assertEquals(LocalDate.of(2026, 11, 2), t.dueDate());
        assertEquals(Priority.MEDIUM, t.priority());
    }

    @Test
    void multipleTasksInOneSentence() {
        List<ParsedTask> r = parser.parse(
                "I have to submit my Java assignment tomorrow, prepare for the DBMS exam next Monday, "
                        + "and finish my project presentation urgently.", TODAY);
        assertEquals(3, r.size());
        assertEquals("Submit Java assignment", r.get(0).title());
        assertEquals(Priority.HIGH, r.get(0).priority());
        assertEquals(Priority.MEDIUM, r.get(1).priority());
        assertEquals(TODAY, r.get(2).dueDate());           // urgent, no date -> today
        assertEquals(Priority.HIGH, r.get(2).priority());
    }

    @Test
    void doesNotSplitListsOfNouns() {
        assertEquals(1, parser.parse("Buy milk, eggs and bread tomorrow", TODAY).size());
        assertEquals(1, parser.parse("Read and write essays by Friday", TODAY).size());
    }

    @Test
    void lowPriorityAndRelativeDates() {
        ParsedTask t = parser.parse("pay electricity bill in 3 days, low priority", TODAY).get(0);
        assertEquals("Pay electricity bill", t.title());
        assertEquals(LocalDate.of(2026, 11, 3), t.dueDate());
        assertEquals(Priority.LOW, t.priority());
    }

    @Test
    void emptyOrDateOnlyInputGivesNoTasks() {
        assertTrue(parser.parse("", TODAY).isEmpty());
        assertTrue(parser.parse(null, TODAY).isEmpty());
        assertTrue(parser.parse("tomorrow", TODAY).isEmpty());
    }
}
