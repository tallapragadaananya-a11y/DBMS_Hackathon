package com.taskpilot.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Audit record. Deliberately has no foreign key to Task so the history
 * survives after a task is deleted.
 */
@Entity
@Table(name = "task_history")
public class TaskHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long taskId;

    private String taskTitle;

    /** CREATED, UPDATED, STATUS_CHANGED, DELETED */
    @Column(nullable = false, length = 30)
    private String action;

    @Column(length = 1000)
    private String details;

    @Column(nullable = false)
    private LocalDateTime changedAt;

    protected TaskHistory() {}

    public TaskHistory(Long taskId, String taskTitle, String action, String details) {
        this.taskId = taskId;
        this.taskTitle = taskTitle;
        this.action = action;
        this.details = details;
        this.changedAt = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public Long getTaskId() { return taskId; }
    public String getTaskTitle() { return taskTitle; }
    public String getAction() { return action; }
    public String getDetails() { return details; }
    public LocalDateTime getChangedAt() { return changedAt; }
}
