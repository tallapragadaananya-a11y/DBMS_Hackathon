package com.taskpilot.dto;

public record StatsResponse(
        long total,
        long pending,
        long inProgress,
        long completed,
        long overdue,
        long dueToday,
        long highPriorityOpen,
        int completionRate) {
}
