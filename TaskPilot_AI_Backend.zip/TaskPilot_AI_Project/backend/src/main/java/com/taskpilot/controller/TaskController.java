package com.taskpilot.controller;

import com.taskpilot.dto.*;
import com.taskpilot.model.Priority;
import com.taskpilot.model.Status;
import com.taskpilot.model.TaskHistory;
import com.taskpilot.nlp.ParsedTask;
import com.taskpilot.service.TaskService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    private final TaskService service;

    public TaskController(TaskService service) {
        this.service = service;
    }

    /** GET /api/tasks?status=PENDING&priority=HIGH  (both filters optional) */
    @GetMapping
    public List<TaskResponse> getAll(@RequestParam(required = false) String status,
                                     @RequestParam(required = false) String priority) {
        return service.getAll(Status.parse(status), Priority.parse(priority));
    }

    @GetMapping("/{id}")
    public TaskResponse getOne(@PathVariable Long id) {
        return service.getById(id);
    }

    /** Manual task creation. */
    @PostMapping
    public ResponseEntity<TaskResponse> create(@Valid @RequestBody TaskRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(request));
    }

    /** AI task extraction: one sentence in, one or more saved tasks out. */
    @PostMapping("/quick-add")
    public ResponseEntity<List<TaskResponse>> quickAdd(@Valid @RequestBody QuickAddRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.quickAdd(request.text()));
    }

    /** Dry run of the NLP engine: shows what would be extracted, saves nothing. */
    @PostMapping("/parse")
    public List<ParsedTask> parse(@Valid @RequestBody QuickAddRequest request) {
        return service.preview(request.text());
    }

    @PutMapping("/{id}")
    public TaskResponse update(@PathVariable Long id, @Valid @RequestBody TaskRequest request) {
        return service.update(id, request);
    }

    @PatchMapping("/{id}/status")
    public TaskResponse updateStatus(@PathVariable Long id, @Valid @RequestBody StatusUpdateRequest request) {
        return service.updateStatus(id, request.status());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/stats")
    public StatsResponse stats() {
        return service.stats();
    }

    @GetMapping("/suggestions")
    public SuggestionsResponse suggestions() {
        return service.suggestions();
    }

    /** All history, newest first. */
    @GetMapping("/history")
    public List<TaskHistory> history() {
        return service.history(null);
    }

    @GetMapping("/{id}/history")
    public List<TaskHistory> historyForTask(@PathVariable Long id) {
        return service.history(id);
    }
}
