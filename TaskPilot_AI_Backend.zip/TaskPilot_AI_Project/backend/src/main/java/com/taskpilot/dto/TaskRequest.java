package com.taskpilot.dto;

import com.taskpilot.model.Priority;
import com.taskpilot.model.Status;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;

public record TaskRequest(
        @NotBlank(message = "title is required")
        @Size(max = 255, message = "title must be at most 255 characters")
        String title,

        @Size(max = 1000, message = "description must be at most 1000 characters")
        String description,

        LocalDate dueDate,
        Priority priority,
        Status status) {
}
