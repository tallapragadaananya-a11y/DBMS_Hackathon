package com.taskpilot.model;

public enum Status {
    PENDING, IN_PROGRESS, COMPLETED;

    /** Null/blank -> null (no filter). Unknown value -> IllegalArgumentException (HTTP 400). */
    public static Status parse(String value) {
        if (value == null || value.isBlank()) return null;
        try {
            return Status.valueOf(value.trim().toUpperCase().replace(' ', '_').replace('-', '_'));
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(
                    "Invalid status '" + value + "'. Allowed: PENDING, IN_PROGRESS, COMPLETED");
        }
    }
}
