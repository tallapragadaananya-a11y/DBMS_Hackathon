package com.taskpilot.model;

public enum Priority {
    LOW, MEDIUM, HIGH;

    /** Null/blank -> null (no filter). Unknown value -> IllegalArgumentException (HTTP 400). */
    public static Priority parse(String value) {
        if (value == null || value.isBlank()) return null;
        try {
            return Priority.valueOf(value.trim().toUpperCase().replace(' ', '_'));
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid priority '" + value + "'. Allowed: LOW, MEDIUM, HIGH");
        }
    }
}
