package com.taskpilot.repository;

import com.taskpilot.model.TaskHistory;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TaskHistoryRepository extends JpaRepository<TaskHistory, Long> {
    List<TaskHistory> findAllByOrderByChangedAtDescIdDesc();
    List<TaskHistory> findByTaskIdOrderByChangedAtDescIdDesc(Long taskId);
}
