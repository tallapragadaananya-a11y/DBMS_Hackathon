package com.taskpilot.service;

import com.taskpilot.dto.*;
import com.taskpilot.exception.ResourceNotFoundException;
import com.taskpilot.model.*;
import com.taskpilot.nlp.NlpTaskParser;
import com.taskpilot.nlp.ParsedTask;
import com.taskpilot.repository.TaskHistoryRepository;
import com.taskpilot.repository.TaskRepository;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TaskService {

    private final TaskRepository taskRepository;
    private final TaskHistoryRepository historyRepository;
    private final NlpTaskParser parser;

    public TaskService(TaskRepository taskRepository,
                       TaskHistoryRepository historyRepository,
                       NlpTaskParser parser) {
        this.taskRepository = taskRepository;
        this.historyRepository = historyRepository;
        this.parser = parser;
    }

    // ------------------------------------------------------------------ queries

    @Transactional(readOnly = true)
    public List<TaskResponse> getAll(Status status, Priority priority) {
        LocalDate today = LocalDate.now();
        return taskRepository.findAll().stream()
                .filter(t -> status == null || t.getStatus() == status)
                .filter(t -> priority == null || t.getPriority() == priority)
                .sorted(taskOrder())
                .map(t -> TaskResponse.from(t, today))
                .toList();
    }

    @Transactional(readOnly = true)
    public TaskResponse getById(Long id) {
        return TaskResponse.from(find(id), LocalDate.now());
    }

    @Transactional(readOnly = true)
    public StatsResponse stats() {
        LocalDate today = LocalDate.now();
        List<Task> all = taskRepository.findAll();
        long pending = all.stream().filter(t -> t.getStatus() == Status.PENDING).count();
        long inProgress = all.stream().filter(t -> t.getStatus() == Status.IN_PROGRESS).count();
        long completed = all.stream().filter(t -> t.getStatus() == Status.COMPLETED).count();
        long overdue = all.stream().filter(t -> isOverdue(t, today)).count();
        long dueToday = all.stream()
                .filter(t -> t.getStatus() != Status.COMPLETED && today.equals(t.getDueDate())).count();
        long highOpen = all.stream()
                .filter(t -> t.getStatus() != Status.COMPLETED && t.getPriority() == Priority.HIGH).count();
        int rate = all.isEmpty() ? 0 : (int) Math.round(completed * 100.0 / all.size());
        return new StatsResponse(all.size(), pending, inProgress, completed, overdue, dueToday, highOpen, rate);
    }

    /** "Smart suggestions": overdue tasks and urgent (high priority, due within 2 days) tasks. */
    @Transactional(readOnly = true)
    public SuggestionsResponse suggestions() {
        LocalDate today = LocalDate.now();
        List<Task> open = taskRepository.findAll().stream()
                .filter(t -> t.getStatus() != Status.COMPLETED)
                .sorted(taskOrder())
                .toList();

        List<TaskResponse> overdue = open.stream()
                .filter(t -> isOverdue(t, today))
                .map(t -> TaskResponse.from(t, today)).toList();

        List<TaskResponse> urgent = open.stream()
                .filter(t -> !isOverdue(t, today))
                .filter(t -> t.getPriority() == Priority.HIGH
                        && (t.getDueDate() == null || !t.getDueDate().isAfter(today.plusDays(2))))
                .map(t -> TaskResponse.from(t, today)).toList();

        List<String> messages = new ArrayList<>();
        if (!overdue.isEmpty()) {
            messages.add("You have " + overdue.size() + " overdue task(s). Start with \""
                    + overdue.get(0).title() + "\".");
        }
        if (!urgent.isEmpty()) {
            messages.add(urgent.size() + " high-priority task(s) need attention in the next 2 days.");
        }
        if (messages.isEmpty()) {
            messages.add("You're on track. No overdue or urgent tasks right now.");
        }
        return new SuggestionsResponse(overdue, urgent, messages);
    }

    @Transactional(readOnly = true)
    public List<TaskHistory> history(Long taskId) {
        return taskId == null
                ? historyRepository.findAllByOrderByChangedAtDescIdDesc()
                : historyRepository.findByTaskIdOrderByChangedAtDescIdDesc(taskId);
    }

    // ------------------------------------------------------------------ NLP

    /** Parse text and return what would be created, without saving anything. */
    public List<ParsedTask> preview(String text) {
        return parser.parse(text, LocalDate.now());
    }

    @Transactional
    public List<TaskResponse> quickAdd(String text) {
        LocalDate today = LocalDate.now();
        List<ParsedTask> parsed = parser.parse(text, today);
        if (parsed.isEmpty()) {
            throw new IllegalArgumentException(
                    "Could not find any task in that text. Try something like "
                            + "\"Finish Java assignment tomorrow urgent\".");
        }
        String source = text.trim();
        List<TaskResponse> created = new ArrayList<>();
        for (ParsedTask p : parsed) {
            Task task = new Task();
            task.setTitle(p.title());
            task.setDueDate(p.dueDate());
            task.setPriority(p.priority());
            task.setStatus(Status.PENDING);
            task.setSourceText(source);
            Task saved = taskRepository.save(task);
            log(saved, "CREATED", "Created from natural language: \"" + source + "\"");
            created.add(TaskResponse.from(saved, today));
        }
        return created;
    }

    // ------------------------------------------------------------------ commands

    @Transactional
    public TaskResponse create(TaskRequest req) {
        Task task = new Task();
        apply(task, req);
        Task saved = taskRepository.save(task);
        log(saved, "CREATED", "Created manually");
        return TaskResponse.from(saved, LocalDate.now());
    }

    @Transactional
    public TaskResponse update(Long id, TaskRequest req) {
        Task task = find(id);
        Status oldStatus = task.getStatus();
        apply(task, req);
        Task saved = taskRepository.save(task);
        log(saved, "UPDATED", "Task details updated");
        if (oldStatus != saved.getStatus()) {
            log(saved, "STATUS_CHANGED", oldStatus + " -> " + saved.getStatus());
        }
        return TaskResponse.from(saved, LocalDate.now());
    }

    @Transactional
    public TaskResponse updateStatus(Long id, Status newStatus) {
        Task task = find(id);
        Status old = task.getStatus();
        if (old != newStatus) {
            task.setStatus(newStatus);
            task = taskRepository.save(task);
            log(task, "STATUS_CHANGED", old + " -> " + newStatus);
        }
        return TaskResponse.from(task, LocalDate.now());
    }

    @Transactional
    public void delete(Long id) {
        Task task = find(id);
        log(task, "DELETED", "Task deleted");
        taskRepository.delete(task);
    }

    // ------------------------------------------------------------------ helpers

    private Task find(Long id) {
        return taskRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Task " + id + " not found"));
    }

    private void apply(Task task, TaskRequest req) {
        task.setTitle(req.title().trim());
        task.setDescription(req.description() == null || req.description().isBlank()
                ? null : req.description().trim());
        task.setDueDate(req.dueDate());
        task.setPriority(req.priority() != null ? req.priority() : Priority.MEDIUM);
        task.setStatus(req.status() != null ? req.status() : Status.PENDING);
    }

    private void log(Task task, String action, String details) {
        String d = details.length() > 990 ? details.substring(0, 990) + "..." : details;
        historyRepository.save(new TaskHistory(task.getId(), task.getTitle(), action, d));
    }

    private boolean isOverdue(Task t, LocalDate today) {
        return t.getStatus() != Status.COMPLETED && t.getDueDate() != null && t.getDueDate().isBefore(today);
    }

    /** Open tasks first, then by due date (no date last), then HIGH before LOW. */
    private Comparator<Task> taskOrder() {
        return Comparator
                .comparing((Task t) -> t.getStatus() == Status.COMPLETED)
                .thenComparing(Task::getDueDate, Comparator.nullsLast(Comparator.naturalOrder()))
                .thenComparing(t -> -t.getPriority().ordinal())
                .thenComparing(Task::getId, Comparator.nullsLast(Comparator.naturalOrder()));
    }
}
