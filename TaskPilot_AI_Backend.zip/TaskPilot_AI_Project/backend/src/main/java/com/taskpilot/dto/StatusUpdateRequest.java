package com.taskpilot.dto;

import com.taskpilot.model.Status;
import jakarta.validation.constraints.NotNull;

public record StatusUpdateRequest(
        @NotNull(message = "status is required (PENDING, IN_PROGRESS or COMPLETED)")
        Status status) {
}
