package com.taskpilot.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record QuickAddRequest(
        @NotBlank(message = "text is required")
        @Size(max = 2000, message = "text must be at most 2000 characters")
        String text) {
}
