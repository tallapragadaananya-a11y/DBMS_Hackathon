package com.taskpilot.dto;

import java.util.List;

public record SuggestionsResponse(
        List<TaskResponse> overdue,
        List<TaskResponse> urgent,
        List<String> messages) {
}
