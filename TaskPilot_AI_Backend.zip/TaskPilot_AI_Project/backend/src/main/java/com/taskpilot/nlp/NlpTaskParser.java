package com.taskpilot.nlp;

import com.taskpilot.model.Priority;
import java.time.DateTimeException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Rule-based (explainable) NLP engine.
 *
 * Pipeline for a sentence such as
 *   "I have to submit my Java assignment tomorrow, prepare for the DBMS exam next Monday,
 *    and finish my project presentation urgently."
 *
 *   1. Split into task clauses   (punctuation + "and/then/also" before an action verb)
 *   2. Detect priority keywords  (urgent, asap, high priority, low priority, no rush ...)
 *   3. Detect the deadline       (today, tomorrow, next Monday, in 3 days, 5 Nov, 2026-11-05 ...)
 *   4. Clean the remaining text into a task title
 *   5. If no priority was stated, infer it from how close the deadline is
 */
public class NlpTaskParser {

    // ------------------------------------------------------------------ vocabulary

    private static final String VERBS = String.join("|",
            "submit", "prepare", "finish", "complete", "buy", "call", "write", "send", "study",
            "revise", "read", "attend", "book", "pay", "clean", "fix", "review", "email", "meet",
            "plan", "practice", "practise", "learn", "visit", "schedule", "create", "build", "make",
            "do", "finalize", "finalise", "update", "organize", "organise", "pick", "return", "renew",
            "order", "cancel", "check", "join", "start", "upload", "download", "install", "print",
            "set", "take", "get", "go", "bring", "collect", "deliver", "drop", "register", "apply",
            "repair", "wash", "cook", "text", "message", "discuss", "present", "test", "deploy",
            "debug", "implement", "design", "research", "solve", "watch", "exercise", "workout",
            "remind", "revise", "setup", "arrange", "contact", "follow", "ask", "clear", "pack");

    private static final String WEEKDAYS =
            "monday|tuesday|wednesday|thursday|friday|saturday|sunday|mon|tues?|wed|thu(?:rs?)?|fri";

    private static final String MONTHS =
            "january|february|march|april|may|june|july|august|september|october|november|december"
                    + "|sept|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec";

    /** Optional preposition that belongs to the date phrase ("by tomorrow", "due on Monday"). */
    private static final String PRE =
            "(?:(?:by|on|before|due(?:\\s+(?:on|by))?|until|till|for)\\s+)?";

    // ------------------------------------------------------------------ clause splitting

    /** Hard boundaries: ; newline, or . ! ? followed by whitespace/end. */
    private static final Pattern HARD_SPLIT = Pattern.compile("[;\\n\\r]+|[.!?]+(?=\\s|$)");

    /** Soft boundary: comma / "and" / "then" / "also" followed by the start of a new action. */
    private static final Pattern SOFT_SPLIT = Pattern.compile(
            "(?i)\\s*(?:,\\s*(?:(?:and|then|also)\\s+)?|\\s+(?:and|then|also)\\s+)"
                    + "(?=(?:(?:i|we)\\s+)?(?:(?:need|have|got|want)\\s+to\\s+|must\\s+|should\\s+)?(?:"
                    + VERBS + ")\\b)");

    private static final Pattern BULLET = Pattern.compile("^(?:[\\s\\-*\u2022]+|\\d+[.)]\\s+)");

    // ------------------------------------------------------------------ title cleaning

    private static final Pattern FILLER = Pattern.compile("(?i)^(?:and|then|also|so|ok|okay|please)\\s+");

    private static final Pattern PHRASE = Pattern.compile("(?i)^(?:"
            + "i(?:'m|\\s+am)\\s+going\\s+to|i(?:'ll|\\s+will)|i(?:'ve|\\s+have)\\s+(?:got\\s+)?to"
            + "|i\\s+(?:need|must|should|want|plan|ought)\\s+to|i(?:'d|\\s+would)\\s+like\\s+to"
            + "|(?:remind\\s+me|reminder)\\s+to|(?:do\\s*n'?t|do\\s+not)\\s+forget\\s+to"
            + "|(?:need|have|got|want|ought)\\s+to|must|should|going\\s+to|let'?s"
            + "|to\\s*-?\\s*do(?=\\s*:)|task(?=\\s*:)"
            + ")(?:\\s*:\\s*|\\s+)");

    private static final Pattern MY = Pattern.compile("(?i)\\bmy\\b");

    private static final Pattern LEADING_JUNK = Pattern.compile(
            "(?i)^(?:[\\s,.;:\\-\u2013]|\\b(?:and|then|also|to|by|on|at|before|due|until|till|is|are|please)\\b)+");

    private static final Pattern TRAILING_JUNK = Pattern.compile(
            "(?i)(?:[\\s,.;:\\-\u2013]|\\b(?:and|then|also|by|on|at|before|due|until|till|is|are|for|in|this|next)\\b)+$");

    // ------------------------------------------------------------------ priority rules

    private record PriorityRule(Pattern pattern, Priority priority, boolean removeFromTitle, boolean impliesToday) {
        static PriorityRule of(String regex, Priority p, boolean remove, boolean today) {
            return new PriorityRule(Pattern.compile("(?i)" + regex), p, remove, today);
        }
    }

    // Order matters: LOW/MEDIUM phrases (incl. "not urgent") are checked before HIGH.
    private static final List<PriorityRule> PRIORITY_RULES = List.of(
            PriorityRule.of("\\bnot\\s+(?:very\\s+)?(?:urgent|important)\\b", Priority.LOW, true, false),
            PriorityRule.of("\\blow(?:est)?[\\s-]+priority\\b", Priority.LOW, true, false),
            PriorityRule.of("\\bno\\s+(?:rush|hurry)\\b", Priority.LOW, true, false),
            PriorityRule.of("\\bwhenever(?:\\s+(?:possible|free))?\\b", Priority.LOW, true, false),
            PriorityRule.of("\\bif\\s+(?:i\\s+)?(?:have|get)\\s+(?:the\\s+)?time\\b", Priority.LOW, true, false),
            PriorityRule.of("\\b(?:medium|normal|moderate|mid)[\\s-]+priority\\b", Priority.MEDIUM, true, false),
            PriorityRule.of("\\b(?:high(?:est)?|top|critical)[\\s-]+priority\\b", Priority.HIGH, true, false),
            PriorityRule.of("\\b(?:very\\s+|extremely\\s+)?urgent(?:ly)?\\b", Priority.HIGH, true, true),
            PriorityRule.of("\\basap\\b", Priority.HIGH, true, true),
            PriorityRule.of("\\b(?:immediately|right\\s+away)\\b", Priority.HIGH, true, true),
            PriorityRule.of("\\bhigh\\s+importance\\b", Priority.HIGH, true, false),
            PriorityRule.of("\\b(?:critical|important)\\b", Priority.HIGH, false, false));

    private record PriorityHit(Priority priority, boolean impliesToday, String remaining) {}

    // ------------------------------------------------------------------ date rules

    private record DateRule(Pattern pattern, BiFunction<Matcher, LocalDate, LocalDate> resolver) {}

    private record DateHit(LocalDate date, String remaining) {}

    private static DateRule rule(String core, BiFunction<Matcher, LocalDate, LocalDate> resolver) {
        return new DateRule(Pattern.compile("(?i)\\b" + PRE + "(?:" + core + ")\\b"), resolver);
    }

    // Order matters: more specific patterns first.
    private static final List<DateRule> DATE_RULES = List.of(
            // 2026-11-05
            rule("(\\d{4})-(\\d{1,2})-(\\d{1,2})",
                    (m, t) -> safeDate(num(m, 1), num(m, 2), num(m, 3))),
            // 05/11/2026 or 05-11-2026 (day first)
            rule("(\\d{1,2})[/-](\\d{1,2})[/-](\\d{4})",
                    (m, t) -> safeDate(num(m, 3), num(m, 2), num(m, 1))),
            rule("day\\s+after\\s+tomorrow", (m, t) -> t.plusDays(2)),
            // in 3 days / in two weeks / in a month
            rule("in\\s+(\\d{1,3}|an?|one|two|three|four|five|six|seven|eight|nine|ten)\\s+(day|week|month)s?",
                    (m, t) -> {
                        int n = wordToNumber(m.group(1));
                        return switch (m.group(2).toLowerCase()) {
                            case "week" -> t.plusWeeks(n);
                            case "month" -> t.plusMonths(n);
                            default -> t.plusDays(n);
                        };
                    }),
            // 5 Nov, 5th of November 2026
            rule("(\\d{1,2})(?:st|nd|rd|th)?\\s+(?:of\\s+)?(" + MONTHS + ")(?:\\s*,?\\s*(\\d{4}))?",
                    (m, t) -> monthDay(num(m, 1), m.group(2), m.group(3), t)),
            // November 5, Nov 5th 2026
            rule("(" + MONTHS + ")\\.?\\s+(\\d{1,2})(?:st|nd|rd|th)?(?:\\s*,?\\s*(\\d{4}))?",
                    (m, t) -> monthDay(num(m, 2), m.group(1), m.group(3), t)),
            rule("tomorrow|tmrw|tmr|2morrow", (m, t) -> t.plusDays(1)),
            rule("today|tonight|this\\s+(?:morning|afternoon|evening)", (m, t) -> t),
            rule("next\\s+week", (m, t) -> t.with(TemporalAdjusters.next(DayOfWeek.MONDAY))),
            rule("(?:this\\s+)?weekend", (m, t) -> t.with(TemporalAdjusters.nextOrSame(DayOfWeek.SATURDAY))),
            rule("end\\s+of\\s+(?:the\\s+)?week|this\\s+week",
                    (m, t) -> t.with(TemporalAdjusters.nextOrSame(DayOfWeek.FRIDAY))),
            // monday / this friday / next monday
            rule("(?:(this|next|coming)\\s+)?(" + WEEKDAYS + ")", (m, t) -> {
                DayOfWeek day = dayOfWeek(m.group(2));
                boolean thisWeek = m.group(1) != null && m.group(1).equalsIgnoreCase("this");
                return thisWeek ? t.with(TemporalAdjusters.nextOrSame(day)) : t.with(TemporalAdjusters.next(day));
            }));

    // ------------------------------------------------------------------ public API

    /** Convenience overload that uses today's date. */
    public List<ParsedTask> parse(String text) {
        return parse(text, LocalDate.now());
    }

    /**
     * @param text  free-form user input, possibly describing several tasks
     * @param today reference date used to resolve "tomorrow", "next Monday", etc.
     * @return the tasks found (empty list if none)
     */
    public List<ParsedTask> parse(String text, LocalDate today) {
        List<ParsedTask> result = new ArrayList<>();
        if (text == null || text.isBlank()) return result;

        String normalized = text.replace('\u2019', '\'').replaceAll("[ \\t]+", " ").trim();

        for (String sentence : HARD_SPLIT.split(normalized)) {
            for (String clause : splitClauses(sentence)) {
                ParsedTask task = parseClause(clause, today);
                if (task != null) result.add(task);
            }
        }
        return result;
    }

    // ------------------------------------------------------------------ implementation

    private List<String> splitClauses(String sentence) {
        List<String> parts = new ArrayList<>();
        Matcher m = SOFT_SPLIT.matcher(sentence);
        int last = 0;
        while (m.find()) {
            String left = sentence.substring(last, m.start());
            boolean comma = m.group().contains(",");
            // Don't split "read and write essays": the left side must have a real task already.
            if (!comma && wordCount(stripPrefixes(left.trim())) < 2) continue;
            parts.add(left);
            last = m.end();
        }
        parts.add(sentence.substring(last));
        return parts;
    }

    private ParsedTask parseClause(String raw, LocalDate today) {
        String clause = BULLET.matcher(raw.trim()).replaceFirst("");
        if (clause.isBlank()) return null;

        PriorityHit p = extractPriority(clause);
        DateHit d = extractDate(p.remaining(), today);

        LocalDate due = d.date();
        if (due == null && p.impliesToday()) due = today;   // "urgently" with no date -> today

        String title = cleanTitle(d.remaining());
        if (title.length() < 2) return null;

        Priority priority = p.priority() != null ? p.priority() : inferPriority(due, today);
        return new ParsedTask(title, due, priority);
    }

    private PriorityHit extractPriority(String clause) {
        Priority found = null;
        boolean impliesToday = false;
        String text = clause;
        for (PriorityRule r : PRIORITY_RULES) {
            Matcher m = r.pattern().matcher(text);
            if (m.find()) {
                if (found == null) {
                    found = r.priority();
                    impliesToday = r.impliesToday();
                }
                if (r.removeFromTitle()) text = m.replaceAll(" ");
            }
        }
        return new PriorityHit(found, impliesToday, text);
    }

    private DateHit extractDate(String clause, LocalDate today) {
        for (DateRule r : DATE_RULES) {
            Matcher m = r.pattern().matcher(clause);
            while (m.find()) {
                LocalDate date = r.resolver().apply(m, today);
                if (date != null) {
                    String rest = clause.substring(0, m.start()) + " " + clause.substring(m.end());
                    return new DateHit(date, rest);
                }
            }
        }
        return new DateHit(null, clause);
    }

    /** No keyword given: the closer the deadline, the higher the priority. */
    private Priority inferPriority(LocalDate due, LocalDate today) {
        if (due == null) return Priority.MEDIUM;
        long days = ChronoUnit.DAYS.between(today, due);
        if (days <= 1) return Priority.HIGH;     // overdue, today, tomorrow
        if (days <= 7) return Priority.MEDIUM;
        return Priority.LOW;
    }

    private String cleanTitle(String s) {
        String t = collapse(s);
        t = stripPrefixes(t);
        t = collapse(MY.matcher(t).replaceAll(" "));
        t = collapse(LEADING_JUNK.matcher(t).replaceFirst(""));
        t = collapse(TRAILING_JUNK.matcher(t).replaceFirst(""));
        if (t.isEmpty()) return t;
        return Character.toUpperCase(t.charAt(0)) + t.substring(1);
    }

    private String stripPrefixes(String s) {
        String t = s;
        String prev;
        do {
            prev = t;
            t = FILLER.matcher(t).replaceFirst("");
            t = PHRASE.matcher(t).replaceFirst("");
        } while (!t.equals(prev));
        return t;
    }

    // ------------------------------------------------------------------ small helpers

    private static String collapse(String s) {
        return s.replaceAll("\\s+", " ").trim();
    }

    private static int wordCount(String s) {
        return s.isBlank() ? 0 : s.trim().split("\\s+").length;
    }

    private static int num(Matcher m, int group) {
        return Integer.parseInt(m.group(group));
    }

    private static LocalDate safeDate(int year, int month, int day) {
        try {
            return LocalDate.of(year, month, day);
        } catch (DateTimeException e) {
            return null;
        }
    }

    private static LocalDate monthDay(int day, String monthName, String year, LocalDate today) {
        int month = monthNumber(monthName);
        if (year != null) return safeDate(Integer.parseInt(year), month, day);
        LocalDate d = safeDate(today.getYear(), month, day);
        if (d != null && d.isBefore(today)) d = safeDate(today.getYear() + 1, month, day);
        return d;
    }

    private static int monthNumber(String name) {
        return switch (name.toLowerCase().substring(0, 3)) {
            case "jan" -> 1; case "feb" -> 2; case "mar" -> 3; case "apr" -> 4;
            case "may" -> 5; case "jun" -> 6; case "jul" -> 7; case "aug" -> 8;
            case "sep" -> 9; case "oct" -> 10; case "nov" -> 11; default -> 12;
        };
    }

    private static DayOfWeek dayOfWeek(String name) {
        return switch (name.toLowerCase().substring(0, 3)) {
            case "mon" -> DayOfWeek.MONDAY;
            case "tue" -> DayOfWeek.TUESDAY;
            case "wed" -> DayOfWeek.WEDNESDAY;
            case "thu" -> DayOfWeek.THURSDAY;
            case "fri" -> DayOfWeek.FRIDAY;
            case "sat" -> DayOfWeek.SATURDAY;
            default -> DayOfWeek.SUNDAY;
        };
    }

    private static int wordToNumber(String w) {
        return switch (w.toLowerCase()) {
            case "a", "an", "one" -> 1;
            case "two" -> 2; case "three" -> 3; case "four" -> 4; case "five" -> 5;
            case "six" -> 6; case "seven" -> 7; case "eight" -> 8; case "nine" -> 9; case "ten" -> 10;
            default -> Integer.parseInt(w);
        };
    }
}
