package com.taskpilot.nlp;

import com.taskpilot.model.Priority;
import java.time.LocalDate;

/** One task extracted from a natural-language sentence. */
public record ParsedTask(String title, LocalDate dueDate, Priority priority) {
}
