package com.taskpilot.dto;

import com.taskpilot.model.Priority;
import com.taskpilot.model.Status;
import com.taskpilot.model.Task;
import java.time.LocalDate;
import java.time.LocalDateTime;

public record TaskResponse(
        Long id,
        String title,
        String description,
        LocalDate dueDate,
        Priority priority,
        Status status,
        boolean overdue,
        String sourceText,
        LocalDateTime createdAt,
        LocalDateTime updatedAt) {

    public static TaskResponse from(Task t, LocalDate today) {
        boolean overdue = t.getDueDate() != null
                && t.getDueDate().isBefore(today)
                && t.getStatus() != Status.COMPLETED;
        return new TaskResponse(t.getId(), t.getTitle(), t.getDescription(), t.getDueDate(),
                t.getPriority(), t.getStatus(), overdue, t.getSourceText(),
                t.getCreatedAt(), t.getUpdatedAt());
    }
}
